/*
 * tick.h
 *
 *  Created on: Aug 24, 2024
 *      Author: 86186
 */

#ifndef INC_TICK_H_
#define INC_TICK_H_

int32_t get_real_tick();


#endif /* INC_TICK_H_ */
