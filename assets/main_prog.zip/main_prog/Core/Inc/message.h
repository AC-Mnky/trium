#ifndef __MESSAGE_H
#define __MESSAGE_H



void send_message(uint8_t data_1, uint8_t data_2, uint8_t data_3, uint8_t data_4, uint8_t data_5, uint8_t data_6, uint8_t data_7, uint8_t data_8);
uint8_t convert(uint16_t data, int num);
#endif
